﻿Imports System.Data.OleDb
Imports System.Data
Public Class distance
    Dim con As OleDbConnection
    Dim cmd As OleDbCommand
    Dim dr As OleDbDataReader
    Dim ra As Integer
    Dim city, a, b As String
    Public Function dista(ByVal lat1 As Double, ByVal lon1 As Double, ByVal lat2 As Double, ByVal lon2 As Double, ByVal unit As Char) As Double
        Dim theta As Double = lon1 - lon2
        Dim dist As Double
        dist = Math.Sin(deg2rad(lat1)) * Math.Sin(deg2rad(lat2)) + Math.Cos(deg2rad(lat1)) * Math.Cos(deg2rad(lat2)) * Math.Cos(deg2rad(theta))
        dist = Math.Acos(dist)
        dist = rad2deg(dist)
        dist = dist * 60 * 1.1515
        If unit = "K" Then
            dist = dist * 1.609344
        ElseIf unit = "N" Then
            dist = dist * 0.8684
        End If
        Return dist
    End Function
    Private Function deg2rad(ByVal deg As Double) As Double
        Return (deg * Math.PI / 180.0)
    End Function

    Private Function rad2deg(ByVal rad As Double) As Double
        Return rad / Math.PI * 180.0
    End Function

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Sairam\Documents\Visual Studio 2012\Projects\RupeshProjectsem6\RupeshSem6.mdb")
        con.Open()
        cmd = New OleDbCommand("Select city from cities ", con)
        dr = cmd.ExecuteReader
        While (dr.Read())
            ComboBox1.Items.Add(dr("city"))
            ComboBox2.Items.Add(dr("city"))
        End While
        ComboBox3.Items.Add("K")
        ComboBox3.Items.Add("M")
        ComboBox3.Items.Add("N")

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        city = ComboBox1.SelectedItem.ToString
        cmd = New OleDbCommand("Select * from cities where city='" + city + "'", con)

        dr = cmd.ExecuteReader
        While dr.Read
            TextBox1.Text = dr("latitude").ToString
            TextBox2.Text = dr("longitude").ToString

        End While

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        city = ComboBox2.SelectedItem.ToString
        cmd = New OleDbCommand("Select * from cities where city='" + city + "'", con)

        dr = cmd.ExecuteReader
        While dr.Read
            TextBox3.Text = dr("latitude").ToString
            TextBox4.Text = dr("longitude").ToString

        End While
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim abc As Double
        a = ComboBox3.SelectedItem.ToString
        abc = dista(Val(TextBox1.Text), Val(TextBox2.Text), Val(TextBox3.Text), Val(TextBox4.Text), a)

        Form5.Show()

        Form5.Label4.Text = ComboBox1.SelectedItem
        Form5.Label5.Text = ComboBox2.SelectedItem
        If a = " K" Then
            Form5.Label6.Text = abc
        ElseIf a = "M" Then
            Form5.Label6.Text = abc
        Else
            Form5.Label6.Text = abc

        End If


    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.SendToBack()
        Me.Hide()
    End Sub
End Class