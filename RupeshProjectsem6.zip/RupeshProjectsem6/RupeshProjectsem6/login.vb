﻿Imports System.Data.OleDb
Imports System.Data

Public Class login

    Dim con As OleDbConnection
    Dim cmd As OleDbCommand
    Dim dr As OleDbDataReader
    Dim ra As Integer


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd = New OleDbCommand("Select * from Admin where  uname='" + TextBox1.Text + "' and pass='" + TextBox2.Text + "'", con)
        dr = cmd.ExecuteReader

        If dr.Read Then

            MsgBox("Hi Rupesh")
            Form3.Show()



        Else

            MsgBox("Invalide UserName Or Passward")
        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.BackColor = Color.Transparent
        Label2.BackColor = Color.Transparent
        con = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Sairam\Documents\Visual Studio 2012\Projects\RupeshProjectsem6\RupeshSem6.mdb")
        con.Open()
        login.Label3.Font.Size = 10


    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        signup.Show()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged



    End Sub
End Class
