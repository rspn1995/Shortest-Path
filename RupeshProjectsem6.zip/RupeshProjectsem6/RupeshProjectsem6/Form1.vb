﻿Imports System.Data.OleDb
Imports System.Data

Public Class login

    Dim con As OleDbConnection
    Dim cmd As OleDbCommand
    Dim dr As OleDbDataReader
    Dim ra As Integer


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd = New OleDbCommand("Select * from Admin where  username='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'", con)
        dr = cmd.ExecuteReader

        If dr.Read Then

            MsgBox("Hi Rupesh")
            Form3.Show()



        Else

            MsgBox("Invalide UserName Or Passward")
        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.BackColor = Color.Transparent
        Label2.BackColor = Color.Transparent
        con = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Sairam\Documents\RupeshSem6.mdb")
        con.Open()
    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        Form2.Show()
    End Sub
End Class
