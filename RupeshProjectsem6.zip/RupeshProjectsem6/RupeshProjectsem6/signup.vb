﻿Imports System.Data.OleDb
Imports System.Data
Public Class signup

    Dim con As OleDbConnection
    Dim cmd As OleDbCommand
    Dim dr As OleDbDataReader
    Dim ra As Integer


    Private Sub exit_2_Click(sender As Object, e As EventArgs) Handles exit_2.Click
        Me.SendToBack()
        Me.Hide()







    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Sairam\Documents\Visual Studio 2012\Projects\RupeshProjectsem6\RupeshSem6.mdb")
        con.Open()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd = New OleDbCommand("insert into Admin (fname,uname,pass,email,mno) values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox5.Text & "'," & TextBox6.Text & ")", con)
        ra = cmd.ExecuteNonQuery
        MessageBox.Show("Submitted Sucessfully")
        Me.SendToBack()
        Me.Hide()
    End Sub
End Class